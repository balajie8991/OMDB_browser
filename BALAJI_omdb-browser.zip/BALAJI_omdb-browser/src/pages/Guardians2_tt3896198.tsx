// pages/movie/[id].tsx

// Import required modules
import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import axios from 'axios';

// Define the MovieViewPage component
const MovieViewPage = () => {
  // Get the router object from Next.js
  const router = useRouter();
  // Extract the 'id' parameter from the router query
  const { id } = router.query;
  // State variable to hold the movie data
  const [movie, setMovie] = useState(null);

  useEffect(() => {
    // Function to fetch movie details using OMDB API
    const fetchMovieDetails = async () => {
      try {
        // GET request to the OMDB API using the provided 'id' parameter and the API key from the environment variable
        const response = await axios.get(
          `https://www.omdbapi.com/?apikey=${process.env.NEXT_PUBLIC_OMDB_API_KEY}&i=${id}`
        );
        setMovie(response.data);
      } catch (error) {
        console.error('Error fetching movie details:', error);
      }
    };

    // If 'id' is available, then fetch movie details
    if (id) {
      fetchMovieDetails();
    }
  }, [id]); // The 'useEffect' hook runs when 'id' changes

  // loading message if the movie data is not available
  if (!movie) {
    return <div>Loading...</div>;
  }

  // Display the movie details once the data is available
  return (
    <div>
      <h1>{movie.Title}</h1>
      <p>{movie.Plot}</p>
      <p>Director: {movie.Director}</p>
      <p>Year: {movie.Year}</p>
    </div>
  );
};

export default MovieViewPage;
