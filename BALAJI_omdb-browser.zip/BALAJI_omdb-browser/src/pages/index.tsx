// Import necessary modules and hooks
import Head from 'next/head';
import { useEffect, useState } from 'react';
import axios from 'axios';
import styles from '@/styles/Search.module.css';

// Define the Search component
const Search = () => {
  // States to manage search term, movie list, current page, total results, and error
  const [searchTerm, setSearchTerm] = useState(''); // The user's search term
  const [movies, setMovies] = useState([]); // List of movies matching the search term
  const [currentPage, setCurrentPage] = useState(1); // The current page number for pagination
  const [totalResults, setTotalResults] = useState(0); // Total number of results for the search term
  const [error, setError] = useState(''); // Error message in case of API request failure

  // Get the OMDB API key from the .env file
  const NEXT_PUBLIC_OMDB_API_KEY = process.env.OMDB_API_KEY;

  // Number of movies to display per page
  const ITEMS_PER_PAGE = 10;

  // Function to handle the movie search
  const handleSearch = async () => {
    try {
      // Make an API request to the OMDB API with the search term and current page
      const response = await axios.get(
        `https://www.omdbapi.com/?s=${encodeURIComponent(searchTerm)}&apikey=${NEXT_PUBLIC_OMDB_API_KEY}&page=${currentPage}`
      );

      // Check if the response was successful
      if (response.data.Response === 'True') {
        // Update the state with the fetched movies and total results
        setMovies(response.data.Search);
        setTotalResults(parseInt(response.data.totalResults));
        setError(''); // Clear any previous error message
      } else {
        // If the response is not successful, clear the movie list, set total results to 0, and display the error message
        setMovies([]);
        setTotalResults(0);
        setError(response.data.Error);
      }
    } catch (error) {
      // Handle any errors that occur during the API request
      console.error('Error searching movies:', error);
    }
  };

  // Effect hook to trigger the search whenever the search term or current page changes
  useEffect(() => {
    if (searchTerm.trim() !== '') {
      handleSearch();
    }
  }, [searchTerm, currentPage]);

  // Function to handle page changes in pagination
  const handlePageChange = (page) => {
    setCurrentPage(page); // Update the current page when a page number is clicked
  };

  // JSX for rendering the Search component
  return (
    <>
      <Head>
        <title>OMDB Browser - Search</title>
        <meta name="description" content="Search the OMDB database." />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <main className={styles.main}>
        {/* Input box and Search button for user to enter search term */}
        <div className={styles.searchContainer}>
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)} // Update the search term state as the user types
            placeholder="Search for movies..."
          />
          <button onClick={() => handleSearch()}>Search</button> {/* Trigger the search when the button is clicked */}
        </div>

        {/* Display the error message if there's an error, otherwise, show the list of movies */}
        {error ? (
          <div>{error}</div>
        ) : (
          <div className={styles.movieList}>
            {/* Map through the movies and render each movie as a separate component */}
            {movies.map((movie) => (
              <div className={styles.movie} key={movie.imdbID}>
                {/* Display the movie thumbnail */}
                <img src={movie.Poster} alt={movie.Title} />
                {/* Display the movie title */}
                <h3>{movie.Title}</h3>
                {/* Display the movie release year */}
                <p>Year: {movie.Year}</p>
              </div>
            ))}
          </div>
        )}

        {/* Display pagination if there are more than one page of results */}
        {totalResults > 0 && (
          <div className={styles.pagination}>
            {/* Map through the number of pages and display page buttons */}
            {Array.from({ length: Math.ceil(totalResults / ITEMS_PER_PAGE) }).map((_, index) => (
              <button key={index + 1} onClick={() => handlePageChange(index + 1)}>
                {index + 1}
              </button>
            ))}
          </div>
        )}
      </main>
    </>
  );
};

export default Search;
